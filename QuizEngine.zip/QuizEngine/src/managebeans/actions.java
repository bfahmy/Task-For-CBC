package managebeans;

public interface actions {
	public void add();

	public void delete(int object);

	public String update();

	public String view(int object);

	public String turnBack();
}
